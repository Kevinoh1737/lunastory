-- ============================================================
-- H&CN Studio — Production Data Dump
-- Generated: 2026-05-15
-- Source: Replit production PostgreSQL
-- ============================================================

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- ------------------------------------------------------------
-- TABLE: tasks
-- ------------------------------------------------------------
TRUNCATE TABLE tasks RESTART IDENTITY CASCADE;

INSERT INTO tasks (id, name, created_at, updated_at) VALUES
(1, 'test',   '2026-04-20 06:50:55.306118+00', '2026-04-20 06:50:55.306118+00'),
(3, 'test',   '2026-04-29 05:31:00.808441+00', '2026-04-29 05:31:00.808441+00'),
(4, 'test 2', '2026-04-30 05:42:53.884167+00', '2026-04-30 05:42:53.884167+00');

SELECT setval('tasks_id_seq', 4, true);

-- ------------------------------------------------------------
-- TABLE: images  (task_id FK → tasks.id)
-- ------------------------------------------------------------
TRUNCATE TABLE images RESTART IDENTITY CASCADE;

INSERT INTO images (id, product_id, task_id, tag, file_name, image_url, prompt, model, overlay_text, status, parent_id, variation_group_id, variation_index, mask_data, created_at, updated_at) VALUES
(1,  NULL, 1, 'general', 'general_task1_f1166b2f-f5c8-4043-bb94-c765b25d1dd1.png', '/api/uploads/general_task1_f1166b2f-f5c8-4043-bb94-c765b25d1dd1.png',
 '제품을 분위기 레퍼런스에 맞는 야외 풀장 이미지로 외국인 아기모델로 만들어줘 뒤에 야자수 나무는 생략해줘',
 'gemini-3.1-flash-image', NULL, 'draft', NULL, NULL, NULL, NULL,
 '2026-04-20 07:24:47.529552+00', '2026-04-23 00:55:38.867+00'),
(2,  NULL, 1, 'general', 'general_task1_dcfe55b8-92a3-444a-b600-16957cec6c87.png', '/api/uploads/general_task1_dcfe55b8-92a3-444a-b600-16957cec6c87.png',
 '제품이미지의 튜브 1개를  야외에 합성해줘',
 'gemini-3.1-flash-image', NULL, 'draft', NULL, NULL, NULL, NULL,
 '2026-04-20 07:44:51.45207+00', '2026-04-20 07:44:51.45207+00'),
(3,  NULL, 1, 'general', 'general_task1_ab03103a-e0fe-4476-94a2-6f72f3c84642.png', '/api/uploads/general_task1_ab03103a-e0fe-4476-94a2-6f72f3c84642.png',
 '제품이미지의 튜브 1개를  야외에 합성해줘',
 'gemini-3.1-flash-image', NULL, 'draft', NULL, NULL, NULL, NULL,
 '2026-04-20 07:44:55.164022+00', '2026-04-20 07:44:55.164022+00'),
(4,  NULL, 1, 'general', 'general_task1_a9aadc5d-4914-4731-ba9f-6e8a96e934b0.png', '/api/uploads/general_task1_a9aadc5d-4914-4731-ba9f-6e8a96e934b0.png',
 '제품 이미지 1의 모델에 2의 수영복을 입혀줘',
 'gemini-3.1-flash-image', NULL, 'draft', NULL, NULL, NULL, NULL,
 '2026-04-20 08:02:38.518977+00', '2026-04-20 08:02:38.518977+00'),
(5,  NULL, 1, 'general', 'general_task1_d1bc223f-8a77-4351-9a33-23b7379e8bb2.png', '/api/uploads/general_task1_d1bc223f-8a77-4351-9a33-23b7379e8bb2.png',
 '제품이미지에 외국인 아기모델이 기어가는 모습 합성해줘',
 'gemini-3.1-flash-image', NULL, 'draft', NULL, NULL, NULL, NULL,
 '2026-04-22 00:55:12.892012+00', '2026-04-22 00:55:12.892012+00'),
(6,  NULL, 1, 'general', 'general_task1_042abb80-0809-470a-87ba-a77e37ddfb02.png', '/api/uploads/general_task1_042abb80-0809-470a-87ba-a77e37ddfb02.png',
 E'제품이미지에 외국인 아기모델이 기어가는 모습 합성해줘
레퍼런스 이미지에 있는 이불은 없애고 제품이미지의 제품을 합성하고 아기 모델을 합성해줘',
 'gemini-3.1-flash-image', NULL, 'draft', NULL, NULL, NULL, NULL,
 '2026-04-22 01:20:19.664393+00', '2026-04-22 01:20:19.664393+00');

SELECT setval('images_id_seq', 18, true);

-- ------------------------------------------------------------
-- TABLE: video_tasks
-- ------------------------------------------------------------
TRUNCATE TABLE video_tasks RESTART IDENTITY CASCADE;

INSERT INTO video_tasks (id, name, created_at, updated_at) VALUES
(1, '영상',   '2026-04-30 02:41:12.740144+00', '2026-04-30 02:41:12.740144+00'),
(2, '테스트', '2026-05-07 07:06:58.574715+00', '2026-05-07 07:06:58.574715+00'),
(4, '테스트', '2026-05-12 04:10:31.784636+00', '2026-05-12 04:10:31.784636+00');

SELECT setval('video_tasks_id_seq', 4, true);

-- ------------------------------------------------------------
-- TABLE: videos  (video_task_id FK → video_tasks.id)
-- NOTE: video_url is empty — the Veo generation was still "generating"
--       at dump time and no output file was produced.
--       source_image_url points to /api/uploads/source_image_*.jpg
--       (include that file from the uploads/ folder in this archive).
-- ------------------------------------------------------------
TRUNCATE TABLE videos RESTART IDENTITY CASCADE;

INSERT INTO videos (id, video_task_id, name, file_name, video_url, source_type, source_image_url, source_video_url, prompt, model, replicate_prediction_id, status, error_message, created_at, updated_at) VALUES
(1, 1,
 '비교_2026. 5. 7. [veo-3.1]',
 '',
 '',
 'i2v',
 '/api/uploads/source_image_0fea7f2e-247d-49e2-ab0a-30ac56d20475.jpg',
 NULL,
 'A joyful baby girl, no older than 12 months, giggling and splashing gently while sitting comfortably in a vibrant, inflatable swim tube. A slow, smooth dolly-in shot transitions to a low-angle tracking shot, following her as she kicks her tiny feet, reaches out with curiosity, and watches the water ripple. Shot with an 85mm portrait lens, featuring a very shallow depth of field that keeps her bright eyes and happy expression in sharp focus, while the background water blurs into a soft bokeh. Golden hour sun casts a warm, soft rim light on her hair and skin, creating sparkling highlights on the water''s surface. The scene is full of innocent wonder and playful serenity. Cinematic 4K, 120fps slow motion, with a warm, slightly desaturated but vibrant color grade, emphasizing the soft aqua blues of the water and the gentle yellow or pink of the tube. Calm, clear water, possibly a pool or very still lake.',
 'veo-3.1',
 'models/veo-3.1-generate-preview/operations/cd2mwwabtjov',
 'generating',
 NULL,
 '2026-05-07 06:55:11.078316+00', '2026-05-07 06:55:11.078316+00');

SELECT setval('videos_id_seq', 1, true);

-- ------------------------------------------------------------
-- Empty tables (insert nothing, just note them)
-- categories, products, guide_images, detail_pages,
-- detail_page_sections — all had 0 rows at dump time.
-- ------------------------------------------------------------
