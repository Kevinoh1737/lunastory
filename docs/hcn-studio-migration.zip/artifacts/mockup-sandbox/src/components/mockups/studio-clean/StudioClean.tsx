import React, { useState } from "react";
import { Sparkles, Save, Download, Plus, ChevronLeft, ChevronRight, Image as ImageIcon, History, Maximize2, MoreHorizontal, Layers } from "lucide-react";

export default function StudioClean() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [historyOpen, setHistoryOpen] = useState(false);

  return (
    <div 
      className="flex flex-col bg-white text-gray-900 font-sans antialiased overflow-hidden select-none"
      style={{ width: "1280px", height: "900px" }}
    >
      {/* Header */}
      <header className="h-14 flex-none border-b border-gray-200 bg-white flex items-center justify-between px-6 z-10 relative">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-blue-600 font-bold text-lg">
            <Sparkles className="w-5 h-5" />
            <span>H&CN</span>
          </div>
          
          {/* Task Tabs */}
          <div className="flex items-center gap-2">
            {[
              { name: "봄 신상 화보", active: true },
              { name: "여름 제품 촬영", active: false },
              { name: "가을 룩북", active: false },
              { name: "모델 착용 컷", active: false },
            ].map((task, i) => (
              <div 
                key={i} 
                className={`px-3 py-1.5 rounded-md text-sm font-medium cursor-pointer transition-colors ${
                  task.active 
                    ? 'bg-blue-50 text-blue-600' 
                    : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                {task.name}
              </div>
            ))}
            <button className="p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-900 rounded-md transition-colors ml-1">
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Save className="w-4 h-4" />
            저장
          </button>
          <button className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors shadow-sm">
            <Download className="w-4 h-4" />
            다운로드
          </button>
        </div>
      </header>

      {/* Main Layout */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Left Sidebar (Library) */}
        <aside 
          className={`flex-none border-r border-gray-200 bg-gray-50 flex flex-col transition-all duration-300 ${sidebarOpen ? 'w-[240px]' : 'w-[0px] border-r-0'}`}
        >
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            <div>
              <h3 className="text-xs font-semibold text-gray-500 mb-3 uppercase tracking-wider">제품 레퍼런스</h3>
              <div className="grid grid-cols-2 gap-2">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="aspect-square bg-gray-200 rounded-md border border-gray-300 hover:border-blue-500 cursor-pointer flex items-center justify-center group transition-colors">
                    <ImageIcon className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-xs font-semibold text-gray-500 mb-3 uppercase tracking-wider">무드 레퍼런스</h3>
              <div className="grid grid-cols-2 gap-2">
                {[1, 2].map(i => (
                  <div key={i} className="aspect-square bg-gray-200 rounded-md border border-gray-300 hover:border-blue-500 cursor-pointer flex items-center justify-center group transition-colors">
                    <ImageIcon className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-gray-500 mb-3 uppercase tracking-wider">모델 레퍼런스</h3>
              <div className="grid grid-cols-2 gap-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="aspect-square bg-gray-200 rounded-md border border-gray-300 hover:border-blue-500 cursor-pointer flex items-center justify-center group transition-colors">
                    <ImageIcon className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* Sidebar Toggle Button */}
        <div className="relative">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="absolute top-1/2 -translate-y-1/2 -left-3.5 z-20 w-7 h-7 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-900 shadow-sm transition-colors"
          >
            {sidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

        {/* Center Main Area */}
        <main className="flex-1 flex flex-col bg-white min-w-0 relative">
          <div className="flex-1 overflow-y-auto p-8 lg:p-10 max-w-[800px] mx-auto w-full">
            
            <div className="space-y-10">
              {/* Header Section */}
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">이미지 생성 워크스페이스</h1>
                <p className="text-sm text-gray-500">레퍼런스를 구성하고 프롬프트를 입력하여 고품질 이미지를 생성하세요.</p>
              </div>

              {/* Reference Slots Grid */}
              <div className="space-y-6">
                <div className="grid grid-cols-[100px_1fr] gap-6 items-start">
                  <div className="pt-2 text-sm font-medium text-gray-700">제품 (최대 3)</div>
                  <div className="flex gap-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="w-24 h-24 bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center gap-1 hover:bg-gray-100 hover:border-blue-400 cursor-pointer transition-all">
                        <Plus className="w-5 h-5 text-gray-400" />
                        <span className="text-xs text-gray-500 font-medium">슬롯 {i}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-[100px_1fr] gap-6 items-start border-t border-gray-100 pt-6">
                  <div className="pt-2 text-sm font-medium text-gray-700">무드 (1)</div>
                  <div className="flex gap-4">
                    <div className="w-24 h-24 bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center gap-1 hover:bg-gray-100 hover:border-blue-400 cursor-pointer transition-all">
                      <Plus className="w-5 h-5 text-gray-400" />
                      <span className="text-xs text-gray-500 font-medium">슬롯 1</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-[100px_1fr] gap-6 items-start border-t border-gray-100 pt-6">
                  <div className="pt-2 text-sm font-medium text-gray-700">모델 (최대 2)</div>
                  <div className="flex gap-4">
                    {[1, 2].map(i => (
                      <div key={i} className="w-24 h-24 bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center gap-1 hover:bg-gray-100 hover:border-blue-400 cursor-pointer transition-all">
                        <Plus className="w-5 h-5 text-gray-400" />
                        <span className="text-xs text-gray-500 font-medium">슬롯 {i}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Prompt Input */}
              <div className="pt-8 border-t border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-900">생성 프롬프트</label>
                  <button className="text-xs text-blue-600 font-medium hover:text-blue-700">추천 프롬프트 보기</button>
                </div>
                <div className="bg-white border border-gray-300 rounded-xl overflow-hidden focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition-all shadow-sm">
                  <textarea 
                    className="w-full h-32 p-4 text-sm text-gray-900 placeholder-gray-400 resize-none outline-none"
                    placeholder="생성하고 싶은 이미지를 상세히 설명해주세요..."
                    defaultValue="럭셔리한 실내 스튜디오 배경, 부드러운 자연광, 따뜻한 톤, 초고화질, 사실적인 질감"
                  />
                  <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
                    <div className="text-xs text-gray-500">
                      팁: 조명과 분위기를 명확히 적어주시면 좋습니다.
                    </div>
                    <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg flex items-center gap-2 transition-colors shadow-sm">
                      <Sparkles className="w-4 h-4" />
                      이미지 생성하기
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </main>

        {/* Right Area (Results) */}
        <aside className="w-[360px] flex-none border-l border-gray-200 bg-gray-50 flex flex-col">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-white">
            <h2 className="text-sm font-bold text-gray-900">생성 결과</h2>
            <span className="text-xs font-medium px-2 py-1 bg-gray-100 text-gray-600 rounded-md">3건 생성됨</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className={`bg-white p-2 rounded-xl border ${i === 1 ? 'border-blue-500 ring-2 ring-blue-100' : 'border-gray-200'} shadow-sm group`}>
                <div className="aspect-[4/5] bg-gray-100 rounded-lg overflow-hidden relative mb-2">
                  <div className="absolute inset-0 flex items-center justify-center text-gray-300">
                    <ImageIcon className="w-10 h-10" />
                  </div>
                  {i === 1 && (
                    <div className="absolute top-3 left-3 bg-blue-600 text-white text-xs px-2 py-1 rounded font-medium shadow-sm">
                      현재 선택됨
                    </div>
                  )}
                  <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1.5 bg-white/90 hover:bg-white text-gray-700 rounded-md shadow-sm backdrop-blur-sm transition-colors"><Maximize2 className="w-4 h-4" /></button>
                  </div>
                </div>
                <div className="px-2 pb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-gray-600">Variation {i}</span>
                  <button className="p-1 text-gray-400 hover:text-gray-900 rounded"><MoreHorizontal className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>

      {/* History Tree Drawer / Bottom Panel */}
      <div className={`border-t border-gray-200 bg-white transition-all duration-300 flex flex-col ${historyOpen ? 'h-[280px]' : 'h-12'}`}>
        <div 
          className="h-12 px-6 flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
          onClick={() => setHistoryOpen(!historyOpen)}
        >
          <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <History className="w-4 h-4" />
            계보 트리 (히스토리)
          </div>
          <button className="text-xs text-gray-500 hover:text-gray-900 font-medium flex items-center gap-1">
            {historyOpen ? '닫기' : '히스토리 트리 열기'}
            <ChevronRight className={`w-4 h-4 transition-transform duration-300 ${historyOpen ? 'rotate-90' : ''}`} />
          </button>
        </div>
        
        {/* Tree Content */}
        <div className="flex-1 p-6 overflow-x-auto bg-gray-50/50 flex items-center">
          <div className="flex items-center gap-8 min-w-max">
            {/* Root Node */}
            <div className="flex flex-col items-center gap-2 relative">
              <div className="w-24 h-24 bg-white rounded-lg border border-gray-300 shadow-sm flex items-center justify-center p-1">
                <div className="w-full h-full bg-gray-100 rounded flex items-center justify-center">
                  <ImageIcon className="w-6 h-6 text-gray-300" />
                </div>
              </div>
              <div className="text-center">
                <div className="text-xs font-bold text-gray-900">V1</div>
                <div className="text-[10px] text-gray-500">초기 생성</div>
              </div>
            </div>

            {/* Connecting Line */}
            <div className="w-12 h-px bg-gray-300 relative">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-2 h-2 rounded-full border-2 border-gray-300 bg-white" />
            </div>

            {/* Child Node */}
            <div className="flex flex-col items-center gap-2 relative">
              <div className="w-28 h-28 bg-white rounded-lg border-2 border-blue-500 shadow-md flex items-center justify-center p-1 ring-4 ring-blue-50">
                <div className="w-full h-full bg-gray-100 rounded flex items-center justify-center">
                  <ImageIcon className="w-8 h-8 text-gray-300" />
                </div>
              </div>
              <div className="text-center">
                <div className="text-xs font-bold text-blue-600">V1.1 (현재)</div>
                <div className="text-[10px] text-gray-500">조명 수정</div>
              </div>
            </div>

            {/* Branch Line */}
            <div className="h-24 w-px bg-gray-300 absolute left-[152px] top-1/2 -translate-y-full" />
            <div className="w-12 h-px bg-gray-300 absolute left-[152px] top-1/4 -translate-y-1/2" />
            
            {/* Alternate Branch */}
            <div className="flex flex-col items-center gap-2 absolute left-[216px] top-0 -translate-y-[10px] opacity-60 hover:opacity-100 transition-opacity">
              <div className="w-20 h-20 bg-white rounded-lg border border-gray-300 shadow-sm flex items-center justify-center p-1 cursor-pointer">
                <div className="w-full h-full bg-gray-100 rounded flex items-center justify-center">
                  <ImageIcon className="w-5 h-5 text-gray-300" />
                </div>
              </div>
              <div className="text-center">
                <div className="text-[10px] font-bold text-gray-700">V2</div>
              </div>
            </div>

          </div>
        </div>
      </div>

    </div>
  );
}
