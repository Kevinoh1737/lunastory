import React, { useState } from "react";
import { Download, Save, Layers, Image as ImageIcon, Sparkles, Folder, History, Paintbrush, ChevronRight, Share2, ZoomIn, BoxSelect, Maximize } from "lucide-react";

export default function StudioDark() {
  const [activeTab, setActiveTab] = useState("제품");

  return (
    <div 
      className="flex flex-col text-[#e8e8e8] font-sans antialiased overflow-hidden select-none"
      style={{ width: "1280px", height: "900px", backgroundColor: "#1e1e1e" }}
    >
      {/* Top Bar */}
      <header className="h-14 flex-none border-b border-[#3a3a3a] bg-[#252525] flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-[#4a9cf6] font-bold text-lg tracking-wider">
            <Sparkles className="w-5 h-5" />
            <span>H&CN</span>
          </div>
          <div className="h-5 w-px bg-[#3a3a3a]" />
          <div className="flex items-center gap-2 group cursor-pointer hover:bg-[#333] px-2 py-1 rounded">
            <span className="text-[15px] font-medium">봄 신상 화보</span>
            <Paintbrush className="w-3.5 h-3.5 text-gray-400 group-hover:text-[#4a9cf6]" />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium bg-[#333] hover:bg-[#444] border border-[#3a3a3a] rounded text-[#e8e8e8] transition-colors">
            <Save className="w-4 h-4" />
            저장
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium bg-[#4a9cf6] hover:bg-[#3b82f6] text-white rounded transition-colors">
            <Download className="w-4 h-4" />
            다운로드
          </button>
        </div>
      </header>

      {/* Main Layout */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Left Sidebar */}
        <aside className="w-[220px] flex-none border-r border-[#3a3a3a] bg-[#252525] flex flex-col">
          {/* Task History */}
          <div className="flex-1 flex flex-col min-h-[300px] border-b border-[#3a3a3a]">
            <div className="p-3 border-b border-[#3a3a3a] flex items-center justify-between bg-[#1e1e1e]">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">테스크 히스토리</span>
              <History className="w-3.5 h-3.5 text-gray-400" />
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              {[
                { name: "봄 신상 화보", date: "2024.03.15", count: 12, active: true },
                { name: "여름 제품 촬영", date: "2024.03.10", count: 8, active: false },
                { name: "가을 룩북", date: "2024.03.05", count: 23, active: false },
                { name: "모델 착용 컷", date: "2024.03.01", count: 5, active: false },
              ].map((task, i) => (
                <div key={i} className={`p-2 rounded cursor-pointer border ${task.active ? 'bg-[#333] border-[#4a9cf6]' : 'border-transparent hover:bg-[#333]'}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-sm ${task.active ? 'text-white' : 'text-[#e8e8e8]'}`}>{task.name}</span>
                    <span className="text-[10px] bg-[#1e1e1e] px-1.5 py-0.5 rounded text-gray-400 border border-[#3a3a3a]">{task.count}</span>
                  </div>
                  <span className="text-xs text-gray-500">{task.date}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Guide Image Library */}
          <div className="h-[400px] flex flex-col">
            <div className="p-3 border-b border-[#3a3a3a] flex items-center justify-between bg-[#1e1e1e]">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">가이드 이미지</span>
              <Folder className="w-3.5 h-3.5 text-gray-400" />
            </div>
            <div className="flex border-b border-[#3a3a3a]">
              {["제품", "무드", "모델"].map((tab) => (
                <button 
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-1.5 text-xs font-medium border-b-2 ${activeTab === tab ? 'border-[#4a9cf6] text-[#4a9cf6] bg-[#333]' : 'border-transparent text-gray-400 hover:text-gray-200'}`}
                >
                  {tab}
                </button>
              ))}
            </div>
            <div className="flex-1 overflow-y-auto p-2 grid grid-cols-2 gap-2 content-start">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="aspect-square bg-[#3a3a3a] rounded border border-[#444] hover:border-[#4a9cf6] cursor-pointer flex items-center justify-center group overflow-hidden">
                  <ImageIcon className="w-5 h-5 text-gray-500 group-hover:text-gray-400" />
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Center Workspace */}
        <main className="flex-1 flex flex-col bg-[#1e1e1e] p-5 gap-5 overflow-y-auto">
          {/* Reference Slots */}
          <div className="bg-[#252525] border border-[#3a3a3a] rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-300 mb-3 flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#4a9cf6]" />
              레퍼런스 이미지 슬롯
            </h3>
            <div className="flex gap-4">
              <div className="flex gap-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="w-20 flex flex-col gap-1">
                    <div className="w-20 h-20 bg-[#333] border border-dashed border-[#555] rounded flex items-center justify-center text-xs text-gray-500">제품{i}</div>
                  </div>
                ))}
              </div>
              <div className="w-px bg-[#3a3a3a] my-1" />
              <div className="flex gap-2">
                <div className="w-20 flex flex-col gap-1">
                  <div className="w-20 h-20 bg-[#333] border border-dashed border-[#555] rounded flex items-center justify-center text-xs text-gray-500">무드1</div>
                </div>
              </div>
              <div className="w-px bg-[#3a3a3a] my-1" />
              <div className="flex gap-2">
                {[1, 2].map((i) => (
                  <div key={i} className="w-20 flex flex-col gap-1">
                    <div className="w-20 h-20 bg-[#333] border border-dashed border-[#555] rounded flex items-center justify-center text-xs text-gray-500">모델{i}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Prompt & Generate */}
          <div className="flex flex-col gap-3">
            <textarea 
              className="w-full h-24 bg-[#252525] border border-[#3a3a3a] rounded-lg p-3 text-sm text-[#e8e8e8] placeholder-gray-500 focus:outline-none focus:border-[#4a9cf6] resize-none"
              placeholder="프롬프트를 입력하세요. (예: 럭셔리한 실내 스튜디오 배경, 부드러운 자연광, 원목 테이블 위)"
              defaultValue="럭셔리한 실내 스튜디오 배경, 부드러운 자연광, 따뜻한 톤, 초고화질, 사실적인 질감"
            />
            <button className="w-full py-3 bg-[#4a9cf6] hover:bg-[#3b82f6] text-white font-medium rounded-lg flex items-center justify-center gap-2 transition-colors shadow-[0_0_15px_rgba(74,156,246,0.3)]">
              <Sparkles className="w-5 h-5" />
              생성하기 (Ctrl+Enter)
            </button>
          </div>

          {/* Results Area */}
          <div className="flex-1 flex flex-col gap-3 mt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-300">생성 결과</h3>
              <span className="text-xs text-gray-500">3개 이미지</span>
            </div>
            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className={`aspect-[4/5] rounded-lg bg-[#2a2a2a] border ${i === 2 ? 'border-[#4a9cf6] ring-1 ring-[#4a9cf6] ring-opacity-50' : 'border-[#3a3a3a]'} overflow-hidden relative group`}>
                  <div className="absolute inset-0 flex items-center justify-center text-gray-600">
                    <ImageIcon className="w-10 h-10 opacity-50" />
                  </div>
                  {i === 2 && (
                    <div className="absolute top-2 right-2 bg-[#4a9cf6] text-white text-[10px] px-1.5 py-0.5 rounded font-bold">
                      선택됨
                    </div>
                  )}
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-3 pt-8 opacity-0 group-hover:opacity-100 transition-opacity flex justify-end gap-2">
                    <button className="p-1.5 bg-[#333] hover:bg-[#4a9cf6] rounded text-white transition-colors"><ZoomIn className="w-4 h-4" /></button>
                    <button className="p-1.5 bg-[#333] hover:bg-[#4a9cf6] rounded text-white transition-colors"><Save className="w-4 h-4" /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>

        {/* Right Sidebar */}
        <aside className="w-[260px] flex-none border-l border-[#3a3a3a] bg-[#252525] flex flex-col">
          {/* Large Preview */}
          <div className="p-3 border-b border-[#3a3a3a]">
            <div className="aspect-[4/5] bg-[#1e1e1e] border border-[#3a3a3a] rounded overflow-hidden relative">
              <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                <ImageIcon className="w-8 h-8" />
              </div>
              <div className="absolute top-2 right-2 p-1 bg-black/50 rounded text-white/80 cursor-pointer hover:text-white">
                <Maximize className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Inpainting */}
          <div className="p-4 border-b border-[#3a3a3a] flex flex-col gap-3">
            <h3 className="text-xs font-semibold text-gray-400 flex items-center gap-1.5">
              <BoxSelect className="w-3.5 h-3.5" />
              인페인팅 / 마스킹
            </h3>
            <div className="flex gap-2 mb-1">
              <button className="flex-1 py-1.5 bg-[#333] hover:bg-[#444] border border-[#3a3a3a] rounded text-xs text-gray-300">브러시</button>
              <button className="flex-1 py-1.5 bg-[#333] hover:bg-[#444] border border-[#3a3a3a] rounded text-xs text-gray-300">올가미</button>
            </div>
            <textarea 
              className="w-full h-16 bg-[#1e1e1e] border border-[#3a3a3a] rounded p-2 text-xs text-[#e8e8e8] placeholder-gray-600 focus:outline-none focus:border-[#4a9cf6] resize-none"
              placeholder="마스킹 영역 프롬프트 (예: 꽃병 추가)"
            />
            <button className="w-full py-1.5 bg-[#333] hover:bg-[#4a9cf6] border border-[#444] hover:border-transparent text-sm text-gray-200 hover:text-white rounded transition-colors">
              부분 재생성
            </button>
          </div>

          {/* Lineage Tree */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="p-3 border-b border-[#3a3a3a] flex items-center justify-between bg-[#1e1e1e]">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">계보 트리</span>
              <Share2 className="w-3.5 h-3.5 text-gray-400" />
            </div>
            <div className="flex-1 p-4 overflow-y-auto bg-[#222]">
              <div className="relative pl-4 space-y-4">
                <div className="absolute top-4 bottom-4 left-[11px] w-px bg-[#444]" />
                
                <div className="relative z-10 flex items-start gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-gray-500 mt-2 -ml-[5px] ring-4 ring-[#222]" />
                  <div className="flex-1 bg-[#333] border border-[#444] p-2 rounded flex gap-2">
                    <div className="w-8 h-8 bg-[#444] rounded" />
                    <div className="flex-1 flex flex-col justify-center">
                      <span className="text-[10px] text-gray-400">V1 (원본)</span>
                      <span className="text-xs text-gray-200">초기 생성</span>
                    </div>
                  </div>
                </div>

                <div className="relative z-10 flex items-start gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#4a9cf6] mt-2 -ml-[5px] ring-4 ring-[#222]" />
                  <div className="flex-1 bg-[#2a364a] border border-[#4a9cf6] p-2 rounded flex gap-2">
                    <div className="w-8 h-8 bg-[#334b6b] rounded border border-[#4a9cf6]" />
                    <div className="flex-1 flex flex-col justify-center">
                      <span className="text-[10px] text-[#4a9cf6]">V1.1 (현재)</span>
                      <span className="text-xs text-blue-100">조명 수정</span>
                    </div>
                  </div>
                </div>

                <div className="relative z-10 flex items-start gap-3 opacity-50">
                  <div className="w-2.5 h-2.5 rounded-full bg-gray-500 mt-2 -ml-[5px] ring-4 ring-[#222]" />
                  <div className="flex-1 bg-[#333] border border-[#444] p-2 rounded flex gap-2">
                    <div className="w-8 h-8 bg-[#444] rounded" />
                    <div className="flex-1 flex flex-col justify-center">
                      <span className="text-[10px] text-gray-400">V2</span>
                      <span className="text-xs text-gray-200">배경 변경</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </aside>

      </div>
    </div>
  );
}
